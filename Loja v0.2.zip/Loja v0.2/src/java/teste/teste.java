
package teste;

import dao.ClienteDAO;
import dao.JPADao;
import dao.PedidoDAO;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import model.Cliente;
import model.Pedido;

/**
 *
 * @author estagiario
 */
public class teste {

    public static void main(String[] args) {
        List<String> lista = new ArrayList();
        PedidoDAO dao = new PedidoDAO();
        ClienteDAO daoCliente = new ClienteDAO();
        
        Cliente cliente = daoCliente.pesquisarPorId((long)1);
        
        Pedido pedido = new Pedido("Ativo", new Date(), cliente);
        
        dao.salvar(pedido);
       
        
    }
}
