package servlet;

import dao.ClienteDAO;
import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import model.Cliente;

@WebServlet("/cadastrar")
public class cadastrar extends HttpServlet {

    private static final long serialVersionUID = 1L;

    @Override

    protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
       
        
        RequestDispatcher rd = request.getRequestDispatcher("/cadastroCliente.jsp");
      
        rd.forward(request, response);
    }

    protected void doGet(HttpServletRequest request,
            HttpServletResponse response) throws ServletException, IOException {
        service(request, response);
    }

    protected void doPost(HttpServletRequest request,
            HttpServletResponse response) throws ServletException, IOException {
        service(request, response);

    }

}
