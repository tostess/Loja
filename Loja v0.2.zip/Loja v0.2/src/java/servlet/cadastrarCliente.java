package servlet;

import dao.ClienteDAO;
import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import model.Cliente;

@WebServlet("/cadastrarCliente")
public class cadastrarCliente extends HttpServlet {

    private static final long serialVersionUID = 1L;

    @Override

    protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String nome = request.getParameter("nome");
        String email = request.getParameter("email");
        String telefone = request.getParameter("telefone");
        System.out.println("Cadastrando cliente " + nome);

        
        Cliente cliente = new Cliente(nome, email, telefone);
        ClienteDAO dao = new ClienteDAO();
        dao.salvar(cliente);

        
        RequestDispatcher rd = request.getRequestDispatcher("/sucesso.jsp");
        request.setAttribute("nome", cliente.getNome());
        rd.forward(request, response);
    }

    protected void doGet(HttpServletRequest request,
            HttpServletResponse response) throws ServletException, IOException {
        service(request, response);
    }

    protected void doPost(HttpServletRequest request,
            HttpServletResponse response) throws ServletException, IOException {
        service(request, response);

    }

}
