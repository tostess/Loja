/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import java.util.Date;
import javax.persistence.Entity;
import javax.persistence.ManyToOne;

/**
 *
 * @author estagiario
 */
@Entity 
public class Pedido extends Identificador{
    
    private String status;    
    private Date data;
    @ManyToOne 
    private Cliente cliente;

    public Pedido() {
    }

    public Pedido(String status, Date data, Cliente cliente) {
        this.cliente = cliente;
        this.status = status;
        this.data = data;
    }

    public Cliente getCliente() {
        return cliente;
    }

    public void setCliente(Cliente cliente) {
        this.cliente = cliente;
    }
    
    
    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public Date getData() {
        return data;
    }

    public void setData(Date data) {
        this.data = data;
    }
    
    
   public Float calcSubTotal(){
       
       return null;
   }

   
    
}
