/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import javax.persistence.Entity;

/**
 *
 * @author estagiario
 */
@Entity
public class Produto extends Identificador {
    private String descricao;
    private Float preco;
    private int quant;

    public Produto(){
    }
    
    public Produto(String descricao, Float preco, int quant) {
        this.descricao = descricao;
        this.preco = preco;
        this.quant = quant;
    }
    
    

    public String getDescricao() {
        return descricao;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }

    public Float getPreco() {
        return preco;
    }

    public void setPreco(Float preco) {
        this.preco = preco;
    }

    public int getQuant() {
        return quant;
    }

    public void setQuant(int quant) {
        this.quant = quant;
    }
    
    
}
