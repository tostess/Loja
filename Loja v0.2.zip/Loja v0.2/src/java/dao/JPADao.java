/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

/**
 *
 * @author estagiario
 */
public class JPADao<T> {

    private final Class<T> persistClass;

   
    public JPADao(Class<T> persistClass) {
        this.persistClass = persistClass;
        
    }
   
    //public JPADao() {
    //}
    static EntityManagerFactory emf = null;
    static EntityManager em = null;
    protected static void openEM(){
        emf = Persistence.createEntityManagerFactory("lojapu");
        em = emf.createEntityManager();
    }
    protected static void closeEM(){
        em.close();
        emf.close();
    }
    protected static void beginTransaction() {
        JPADao.openEM();
        em.getTransaction().begin();
    }
    protected static void commitAndClose(){
        em.getTransaction().commit();
        JPADao.closeEM();
    }
    

    public void salvar(T t) {
    
        JPADao.beginTransaction();
        em.persist(t);
        JPADao.commitAndClose();
        System.out.println("salvo!");
    }
    public void editar(T t){
        
        JPADao.beginTransaction();        
        em.merge(t);
        JPADao.commitAndClose();

        
    }
    public void excluir(T t){
        JPADao.beginTransaction();
        em.remove(t);
        JPADao.commitAndClose();

    }
    
    

}
