/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import java.util.List;
import javax.persistence.Query;
import model.Cliente;

/**
 *
 * @author estagiario
 */
public class ClienteDAO extends JPADao {

    public ClienteDAO() {
        super(Cliente.class);
    }
    
    public List<Cliente> listarClientes(){
        JPADao.openEM();
        Query query = em.createQuery("SELECT e FROM Cliente e");
        List<Cliente> clientes = query.getResultList();
        JPADao.closeEM();
        //emf.close();
        //em.close();
        return clientes;
    }
    public Cliente pesquisarPorId(Long id){
        JPADao.openEM();
        Query query = em.createQuery("SELECT e FROM Cliente e WHERE e.id = " + id);
        Cliente cliente = (Cliente)query.getSingleResult();
        JPADao.closeEM();
        return cliente;
        
    }
}
